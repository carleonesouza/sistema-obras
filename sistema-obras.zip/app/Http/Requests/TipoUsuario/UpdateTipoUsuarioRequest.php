<?php

namespace App\Http\Requests\TipoUsuario;


class UpdateTipoUsuarioRequest extends StoreTipoUsuarioRequest
{
    
}
